<?php 
require('connection.php');
require('header.php');
require('sidebar.php');

$message = ""; // Initialize message variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $doctor_name = $_POST['doctor_name'];
    $doctor_email = $_POST['doctor_email'];
    $doctor_password = $_POST['doctor_password'];

    // Hash the password 
    $hashed_password = md5($doctor_password);

    // Define the role as 'doctor'
    $role = 'doctor';

    // Prepare SQL query to insert the new doctor
    $sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";

    // Prepare and execute the statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssss", $doctor_name, $doctor_email, $hashed_password, $role);
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Doctor account created successfully!</div>";
            $form_id = 'createDoctorForm'; // ID for the form to reset
        } else {
            $message = "<div class='alert alert-danger'>Error: Could not execute query. " . $conn->error . "</div>";
        }
        $stmt->close();
    } else {
        $message = "<div class='alert alert-danger'>Error: Could not prepare statement. " . $conn->error . "</div>";
    }

    // Close the database connection
    $conn->close();
}
?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Create Doctor</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Forms</li>
          <li class="breadcrumb-item active">Create Doctor</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Create Doctor</h5>
 <?php if (isset($message)) echo $message; ?>
                  <!-- Vertical Form -->
                  <form id="createDoctorForm" class="row g-3" action="" method="POST">
                    <div class="col-12">
                      <label for="inputName4" class="form-label">Doctor Name</label>
                      <input type="text" class="form-control" id="inputName4" name="doctor_name" required>
                    </div>
                    <div class="col-12">
                      <label for="inputEmail4" class="form-label">Doctor Email</label>
                      <input type="email" class="form-control" id="inputEmail4" name="doctor_email" required>
                    </div>
                    <div class="col-12">
                      <label for="inputPassword4" class="form-label">Password</label>
                      <input type="password" class="form-control" id="inputPassword4" name="doctor_password" required>
                    </div>

                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form><!-- End Vertical Form -->

                  <!-- Display success or error message -->
                 

                </div>
              </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php require('footer.php'); ?>

 <!-- JavaScript to reset the form -->
 <script>
   document.addEventListener('DOMContentLoaded', function() {
     <?php if (isset($form_id) && $form_id): ?>
       document.getElementById('<?php echo $form_id; ?>').reset();
     <?php endif; ?>
   });
 </script>
