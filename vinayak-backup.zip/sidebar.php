




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sidebar</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <style>
    .sidebar {
      height: 100vh;
      width: 250px;
      background-color: #f8f9fa;
      border-right: 1px solid #dee2e6;
    }
    .sidebar .nav-link {
      color: #495057;
      font-size: 1rem;
      padding: 1rem;
      display: flex;
      align-items: center;
    }
    .sidebar .nav-link:hover {
      background-color: #e9ecef;
      color: #0d6efd;
    }
    .sidebar .nav-link i {
      font-size: 1.25rem;
      margin-right: 0.75rem;
    }
    .sidebar .nav-item {
      border-bottom: 1px solid #dee2e6;
    }
    .sidebar .nav-item:last-child {
      border-bottom: none;
    }
  </style>
</head>
<body>
  <aside id="sidebar" class="sidebar">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create-doctors.php">
          <i class="fas fa-user-md"></i>
          <span>Create Doctors</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create-lab-technician.php">
          <i class="fas fa-flask"></i>
          <span>Create Lab Technician</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create-patient.php">
          <i class="fas fa-procedures"></i>
          <span>Create Patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create-prescription.php">
          <i class="fas fa-users"></i>
          <span>Add  Prescription</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="create-lab-report.php">
          <i class="fas fa-users"></i>
          <span>Add Lab Reports</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tables-general.php">
          <i class="fas fa-users"></i>
          <span>List Staffs</span>
        </a>
      </li>
      <li class="nav-item">
  <a class="nav-link" href="logout.php">
    <i class="fas fa-sign-out-alt"></i>
    <span>Logout</span>
  </a>
</li>

    </ul>
  </aside><!-- End Sidebar -->

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

