<?php
require('connection.php');
require('header.php');
require('sidebar.php');

// Function to get the next patient ID
function getNextPatientId($conn) {
    $query = "SELECT MAX(id) AS max_id FROM patients";
    $result = $conn->query($query);

    if ($result) {
        $row = $result->fetch_assoc();
        $maxId = $row['max_id'];
        return ($maxId ? $maxId + 1 : 132456);
    } else {
        return 132457; 
    }
}

// Get the next patient ID
$nextPatientId = getNextPatientId($conn);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $patient_id = $_POST['patient_id']; // Get the patient ID from the form

    // Validate form data
    if (!empty($name) && !empty($email) && !empty($phone) && !empty($patient_id)) {
        // Prepare the SQL statement to prevent SQL injection
        $query = "INSERT INTO patients (id, name, email, phone) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('isss', $patient_id, $name, $email, $phone); // 'i' for integer, 's' for string
        
        if ($stmt->execute()) {
            echo '<div class="alert alert-success" role="alert">Patient created successfully!</div>';
            // Update the next patient ID for future form displays
            $nextPatientId = getNextPatientId($conn);
        } else {
            echo '<div class="alert alert-danger" role="alert">Error creating patient: ' . $stmt->error . '</div>';
        }
        
        $stmt->close();
    } else {
        echo '<div class="alert alert-warning" role="alert">Please fill in all fields.</div>';
    }
}
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Create Patient</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item">Forms</li>
                <li class="breadcrumb-item active">Create Patient</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Create Patient</h5>

                        <!-- Vertical Form -->
                        <form class="row g-3" method="POST" action="">
                            <div class="col-12">
                                <label for="inputName4" class="form-label">Patient Name</label>
                                <input type="text" name="name" class="form-control" id="inputName4" required>
                            </div>
                            <div class="col-12">
                                <label for="inputPatientId" class="form-label">Patient ID</label>
                                <input type="number" name="patient_id" class="form-control" id="inputPatientId" value="<?php echo $nextPatientId; ?>" readonly required>
                            </div>
                            <div class="col-12">
                                <label for="inputEmail4" class="form-label">Patient Email</label>
                                <input type="email" name="email" class="form-control" id="inputEmail4" required>
                            </div>
                            <div class="col-12">
                                <label for="inputPhone" class="form-label">Patient Phone Number</label>
                                <input type="tel" name="phone" class="form-control" id="inputPhone" required>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form><!-- Vertical Form -->

                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->

<?php require('footer.php'); ?>
