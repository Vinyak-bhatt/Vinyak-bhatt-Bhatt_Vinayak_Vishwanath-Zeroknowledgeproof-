<?php
require('connection.php');
require('header.php');
require('sidebar.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate form data
    if (!empty($name) && !empty($email) && !empty($password)) {
        // Hash the password for security
        $hashed_password = md5($password);

        // Insert user into database
        $query = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'lab_technician')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sss', $name, $email, $hashed_password);
        
        if ($stmt->execute()) {
            echo '<div class="alert alert-success" role="alert">Lab Technician created successfully!</div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">Error creating Lab Technician: ' . $stmt->error . '</div>';
        }
        
        $stmt->close();
    } else {
        echo '<div class="alert alert-warning" role="alert">Please fill in all fields.</div>';
    }
}
?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<main id="main" class="main">
<section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Create Lab Technician</h5>
  <?php if (!empty($message)): ?>
                <?php echo $message; ?>
              <?php endif; ?>
                        <!-- Vertical Form -->
                        <form class="row g-3" method="POST" action="">
                            <div class="col-12">
                                <label for="inputName4" class="form-label">Lab Technician Name</label>
                                <input type="text" name="name" class="form-control" id="inputName4" >
                            </div>
                            <div class="col-12">
                                <label for="inputEmail4" class="form-label">Lab Technician Email</label>
                                <input type="email" name="email" class="form-control" id="inputEmail4" required>
                            </div>
                            <div class="col-12">
                                <label for="inputPassword4" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" id="inputPassword4" required>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form><!-- Vertical Form -->

                    </div>
                </div>
            </div>
        
    </div>
</section>
    </main>

<?php require('footer.php'); ?>

<script>
  // Automatically hide the message after 5 seconds
  setTimeout(function() {
    var messageElement = document.getElementById('message');
    if (messageElement) {
      messageElement.style.display = 'none';
    }
  }, 5000); // 5000 milliseconds = 5 seconds
</script>
