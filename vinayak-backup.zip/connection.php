<?php
$servername = "localhost"; // Change if your DB is hosted elsewhere
$username = "vinayak_db"; // Your database username
$password = "vinayak_db"; // Your database password
$dbname = "vinayak_db";   // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>
