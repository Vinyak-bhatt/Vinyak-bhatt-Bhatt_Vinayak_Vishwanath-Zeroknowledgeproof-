<?php
require('connection.php');

// Get the patient_id from the query parameters
$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;

if ($patient_id) {
    // Fetch the subscription record for the given patient_id
    $query = "SELECT tests FROM create_prescription WHERE patient_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $test_ids = [];

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $test_ids = explode(',', $row['tests']);
    }
    $stmt->close();

    // Output test IDs as JSON
    echo json_encode($test_ids);
} else {
    echo json_encode([]);
}
?>
