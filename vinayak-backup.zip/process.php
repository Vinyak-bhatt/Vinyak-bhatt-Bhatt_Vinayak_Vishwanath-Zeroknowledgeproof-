<?php
session_start();
require 'connection.php';  // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email and password
    if (empty($email) || empty($password)) {
        header('Location: login.php?error=Please enter both email and password');
        exit();
    }

    // Query the database to verify the user
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result === false) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
       
       
  // Verify password (assuming the password is hashed)
        if ((md5($password) === $user['password'])) {
            // Store session information based on the user role
          
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            // Redirect based on user role
            switch ($user['role']) {
                case 'admin':
                    header('Location: dashboard.php');
                    exit();
                case 'doctor':
                    header('Location: doctor_dashboard.php');
                    exit();
                case 'lab_technician':
                    header('Location: lab_dashboard.php');
                    exit();
                default:
                    // If role is not recognized
                    header('Location: login.php?error=Invalid user role');
                    exit();
            }
        } else {
            // Invalid password
            header('Location: logifn.php?error=Invalid password');
            exit();
        }
    } else {
        // Invalid email
        header('Location: logo.php?error=No user found with that email');
        exit();
    }
}
?>
